exports.getPeople = async function(){
    return [
        {
            id: 'zg6j7glicrg88pyy',
            name: 'Bobby',
            favourite_color: {
                name: 'Pickle Green',
                code: '#b9df8d'
            },
            age: 28
        },
        {
            id: 'wzarts0vlqq6m5hy',
            name: 'Amy',
                favourite_color: {
                name: 'Sea Blue',
                    code: '#147fc6'
            },
            age: 17
        },
        {
            id: 'm08dkxyqfr65ju88',
            name: 'Tim',
            favourite_color: {
                name: 'Desert Orange',
                code: '#d48602'
            },
            age: 31
        },
        {
            id: 'nmmoz0ym8vr77rx1',
            name: 'Isabella',
            favourite_color: {
                name: 'Cold Red',
                code: '#d82349'
            },
            age: 38
        },
        {
            id: '7ciktfybixf8fsqi',
            name: 'Kate',
            favourite_color: {
                name: 'Dandelion Yellow',
                code: '#f9e06d'
            },
            age: 16
        }
    ]
}