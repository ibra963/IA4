/**
 * this model specifies the format to exchange userdata with the frontend and store it in mongoDB
 * @param {string} firstname
 * @param {string} lastname
 * @param {int} sid
 * @param {int[]} records
 */
class Salesman{
    constructor(firstname, lastname, sid, records) {
        this.firstname = firstname;
        this.lastname = lastname;
        this.sid = sid;
        this.records = records;
    }
}

module.exports = Salesman;